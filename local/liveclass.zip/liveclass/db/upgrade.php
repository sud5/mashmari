<?php
defined('MOODLE_INTERNAL') || die();

function xmldb_local_liveclass_upgrade($oldversion) {
    global $DB, $CFG;
    $dbman = $DB->get_manager();

    // Define learningpath_cohorts table scheme.
    if ($oldversion < 2020031707) {
        $table = new xmldb_table('users');
        $table->add_field('selected_courseid', XMLDB_TYPE_INTEGER, '5', XMLDB_UNSIGNED, XMLDB_NOTNULL, null, '0');
        $table->add_field('selected_roleid', XMLDB_TYPE_INTEGER, '5', XMLDB_UNSIGNED, XMLDB_NOTNULL, null, '0');

        // Conditionally launch create table.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        upgrade_plugin_savepoint(true, 2020031707, 'local', 'liveclass');
    }

    return true;
}